﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TASKMANAGER21.Models
{
    public partial class Projectd
    {
        public string Prid { get; set; }
        public string Prname { get; set; }
        public string Prdesc { get; set; }
    }
}
